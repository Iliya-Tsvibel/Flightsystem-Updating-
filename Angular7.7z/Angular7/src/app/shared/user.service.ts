import { Injectable } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private fb: FormBuilder, private http: HttpClient) { }
  readonly BaseURI = 'https://localhost:44336/api';

  formModel = this.fb.group({
    FIRST_NAME: ['', Validators.required],
    LAST_NAME: ['', Validators.required],
    USER_NAME: ['', Validators.required],
    ADDRESS: ['', Validators.required],
    PHONE_NO: ['', Validators.required],
    CREDIT_CARD_NUMBER: ['', Validators.required],
    Passwords: this.fb.group({
      PASSWORD: ['', [Validators.required, Validators.minLength(4)]],
      ConfirmPassword: ['', Validators.required]
    }, { validator: this.comparePasswords })

  });

  formModelAirline = this.fb.group({
    AIRLINE_NAME: ['', Validators.required],
    USER_NAME: ['', Validators.required],
    COUNTRY_CODE: ['', Validators.required],
    Passwords: this.fb.group({
      PASSWORD: ['', [Validators.required, Validators.minLength(4)]],
      ConfirmPassword: ['', Validators.required]
    }, { validator: this.comparePasswords })

  });

  comparePasswords(fb: FormGroup) {
    let confirmPswrdCtrl = fb.get('ConfirmPassword');
    //passwordMismatch
    //confirmPswrdCtrl.errors={passwordMismatch:true}
    if (confirmPswrdCtrl.errors == null || 'passwordMismatch' in confirmPswrdCtrl.errors) {
      if (fb.get('PASSWORD').value != confirmPswrdCtrl.value)
        confirmPswrdCtrl.setErrors({ passwordMismatch: true });
      else
        confirmPswrdCtrl.setErrors(null);
    }
  }

  registerAirlineCompany() {
    var body = {
      AIRLINE_NAME: this.formModelAirline.value.AIRLINE_NAME,
      USER_NAME: this.formModelAirline.value.USER_NAME,
      PASSWORD: this.formModelAirline.value.Passwords.PASSWORD,
      COUNTRY_CODE: this.formModelAirline.value.COUNTRY_CODE,
    };
    return this.http.post(this.BaseURI + '/anonymous/airline/new/airlineName', body);
  }
  register() {
    var body = {
      FIRST_NAME: this.formModel.value.FIRST_NAME,
      LAST_NAME: this.formModel.value.LAST_NAME,
      USER_NAME: this.formModel.value.USER_NAME,
      PASSWORD: this.formModel.value.Passwords.PASSWORD,
      ADDRESS: this.formModel.value.ADDRESS,
      PHONE_NO: this.formModel.value.PHONE_NO,
      CREDIT_CARD_NUMBER: this.formModel.value.CREDIT_CARD_NUMBER,
    };
    return this.http.post(this.BaseURI + '/anonymous/customer/new/customerUsername', body);
  }

  login(formData) {
    return this.http.post(this.BaseURI + '/ApplicationUser/Login', formData);
  }

  getUserProfile() {
    return this.http.get(this.BaseURI + '/UserProfile');
  }
}
